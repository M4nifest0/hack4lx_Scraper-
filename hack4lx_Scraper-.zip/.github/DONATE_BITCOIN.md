# Thank you for your donation!

All your donations will be used for the project maintainment and development. If you want to donate another cryptocurrency please [contact](okhlopkov.com).

Bitcoin Address: `1K7jE1pM517tWsX2bLiECGZworQ7B4suXL`.

![QR code](https://bitref.com/qr.php?data=1K7jE1pM517tWsX2bLiECGZworQ7B4suXL)
